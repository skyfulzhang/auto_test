from django.urls import path, include, re_path
from rest_framework.routers import SimpleRouter, DefaultRouter

from AutoAPI.views.ProjectView import ProjectViewSet
from AutoAPI.views.UserView import UserProfileView
from AutoAPI.views.EnvironmentView import EnvironmentViewSet
from AutoAPI.views.APIModuleView import APIModuleViewSet
from AutoAPI.views.APIGroupView import APIGroupViewSet
from AutoAPI.views.APIDetailView import APIDetailViewSet
from AutoAPI.views.APIRequestHistoryView import APIRequestHistoryViewSet
from AutoAPI.views.AutoTestCaseGroupView import AutoTestCaseGroupViewSet
from AutoAPI.views.AutoTestCaseSuiteView import AutoTestCaseSuiteViewSet
from AutoAPI.views.AutoTestCaseAPIView import AutoTestCaseAPIViewSet
from AutoAPI.views.CaseAPIResponseView import CaseAPIResponseViewSet
from AutoAPI.views.DataBaseConnectView import DataBaseConnectViewSet
from AutoAPI.views.SqlScriptView import SqlScriptViewSet
from AutoAPI.views.GlobalVariableView import GlobalVariableViewSet
from AutoAPI.views.AutoCaseTaskView import AutoCaseTaskViewSet

app_name = "AutoAPI"
router = DefaultRouter()
router.register('project', ProjectViewSet, basename="project")
router.register('environment', EnvironmentViewSet, basename="environment")
router.register('api_module', APIModuleViewSet, basename="api_module")
router.register('api_group', APIGroupViewSet, basename="api_group")
router.register('api_detail', APIDetailViewSet, basename="api_detail")
router.register('api_history', APIRequestHistoryViewSet, basename="api_history")
router.register('case_group', AutoTestCaseGroupViewSet, basename="case_group")
router.register('case_suite', AutoTestCaseSuiteViewSet, basename="case_suite")
router.register('case_api', AutoTestCaseAPIViewSet, basename="case_api")
router.register('case_response', CaseAPIResponseViewSet, basename="case_response")
router.register('data_base', DataBaseConnectViewSet, basename="data_base")
router.register('sql_script', SqlScriptViewSet, basename="sql_script")
router.register('variable', GlobalVariableViewSet, basename="variable")
router.register('case_task', AutoCaseTaskViewSet, basename="case_task")
urlpatterns = [
    path('auto/', include((router.urls, "AutoAPI"))),
    path('users/', UserProfileView.as_view()),
    path('users/<pk>/', UserProfileView.as_view()),
]
