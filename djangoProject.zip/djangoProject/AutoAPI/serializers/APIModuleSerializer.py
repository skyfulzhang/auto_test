from django.contrib.auth.models import User
from rest_framework import serializers

from AutoAPI.serializers.BaseSerializer import BaseSerializer
from AutoAPI.models import APIModule
from AutoAPI.serializers.ProjectSerializer import ProjectNestSerializer


# 接口分组反序列化
class APIModuleSerializer(serializers.ModelSerializer, BaseSerializer):
    class Meta:
        model = APIModule
        fields = "__all__"


# 接口分组序列化
class APIModuleOutSerializer(serializers.ModelSerializer, BaseSerializer):
    project = ProjectNestSerializer()
    user = serializers.CharField(source='user.username')

    class Meta:
        model = APIModule
        fields = "__all__"


# 接口分组嵌套序列化
class APIModuleNestSerializer(serializers.ModelSerializer, BaseSerializer):
    project = serializers.CharField(source='project.title')
    user = serializers.CharField(source='user.username')

    class Meta:
        model = APIModule
        fields = "__all__"
