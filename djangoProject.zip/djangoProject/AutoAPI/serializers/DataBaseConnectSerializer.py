from django.contrib.auth.models import User
from rest_framework import serializers

from AutoAPI.serializers.BaseSerializer import BaseSerializer
from AutoAPI.models import DataBaseConnect
from AutoAPI.serializers.ProjectSerializer import ProjectNestSerializer


# 数据库反序列化
class DataBaseConnectSerializer(serializers.ModelSerializer, BaseSerializer):
    class Meta:
        model = DataBaseConnect
        fields = "__all__"


# 数据库序列化
class DataBaseConnectOutSerializer(serializers.ModelSerializer, BaseSerializer):
    project = ProjectNestSerializer()
    user = serializers.CharField(source='user.username')

    class Meta:
        model = DataBaseConnect
        fields = "__all__"


# 数据库嵌套序列化
class DataBaseConnectNestSerializer(serializers.ModelSerializer, BaseSerializer):
    project = serializers.CharField(source='project.title')
    user = serializers.CharField(source='user.username')

    class Meta:
        model = DataBaseConnect
        fields = "__all__"
