from django.contrib.auth.models import User
from rest_framework import serializers

from AutoAPI.serializers.BaseSerializer import BaseSerializer
from AutoAPI.models import APIDetail
from AutoAPI.serializers.APIGroupSerializer import APIGroupNestSerializer
from AutoAPI.serializers.EnvironmentSerializer import EnvironmentNestSerializer


# 接口信息反序列化
class APIDetailSerializer(serializers.ModelSerializer, BaseSerializer):
    class Meta:
        model = APIDetail
        fields = "__all__"


# 接口信息序列化
class APIDetailOutSerializer(serializers.ModelSerializer, BaseSerializer):
    environment = EnvironmentNestSerializer()
    group = APIGroupNestSerializer()
    user = serializers.CharField(source='user.username')

    class Meta:
        model = APIDetail
        fields = "__all__"


# 接口信息嵌套序列化
class APIDetailNestSerializer(serializers.ModelSerializer, BaseSerializer):
    environment = serializers.CharField(source='environment.title')
    group = serializers.CharField(source='group.title')
    user = serializers.CharField(source='user.username')

    class Meta:
        model = APIDetail
        fields = "__all__"
