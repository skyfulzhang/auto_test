from django.contrib.auth.models import User
from rest_framework import serializers

from AutoAPI.serializers.BaseSerializer import BaseSerializer
from AutoAPI.models import AutoTestCaseAPI
from AutoAPI.serializers.APIDetailSerializer import APIDetailNestSerializer
from AutoAPI.serializers.EnvironmentSerializer import EnvironmentNestSerializer
from AutoAPI.serializers.AutoTestCaseSuiteSerializer import AutoTestCaseSuiteNestSerializer


# 测试用例反序列化
class AutoTestCaseAPISerializer(serializers.ModelSerializer, BaseSerializer):
    class Meta:
        model = AutoTestCaseAPI
        fields = "__all__"


# 测试用例序列化
class AutoTestCaseAPIOutSerializer(serializers.ModelSerializer, BaseSerializer):
    check_type_choices = (
        ("NO-CHECK", "no_check"), ("KEY_WORDs", "key_words"), ("COMPILE-CHECK", "complete_check"),)
    assert_type_choices = (
        ("GREATER-THAN", "greater_than"), ("LESS-THAN", "less_than"), ("EQUAL", "equal"), ("NOT-EQUAL", "not_equal"),
        ("CONTAIN", "contain"), ("NOT-CONTAIN", "not_contain"), ("IS-NULL", "is_null"), ("NOT-NULL", "not_null"))
    check_type = serializers.ChoiceField(choices=check_type_choices, source="get_check_type_display")
    assert_type = serializers.ChoiceField(choices=assert_type_choices, source="get_assert_type_display")
    api = APIDetailNestSerializer()
    environment = EnvironmentNestSerializer()
    suite = AutoTestCaseSuiteNestSerializer()
    user = serializers.CharField(source='user.username')

    class Meta:
        model = AutoTestCaseAPI
        fields = "__all__"


# 测试用例嵌套序列化
class AutoTestCaseAPINestSerializer(serializers.ModelSerializer, BaseSerializer):
    check_type_choices = (
        ("NO-CHECK", "no_check"), ("KEY_WORDs", "key_words"), ("COMPILE-CHECK", "complete_check"),)
    assert_type_choices = (
        ("GREATER-THAN", "greater_than"), ("LESS-THAN", "less_than"), ("EQUAL", "equal"), ("NOT-EQUAL", "not_equal"),
        ("CONTAIN", "contain"), ("NOT-CONTAIN", "not_contain"), ("IS-NULL", "is_null"), ("NOT-NULL", "not_null"))
    check_type = serializers.ChoiceField(choices=check_type_choices, source="get_check_type_display")
    assert_type = serializers.ChoiceField(choices=assert_type_choices, source="get_assert_type_display")
    api = serializers.CharField(source='api.name')
    environment = serializers.CharField(source='environment.title')
    suite = serializers.CharField(source='suite.title')
    user = serializers.CharField(source='user.username')

    class Meta:
        model = AutoTestCaseAPI
        fields = "__all__"
