from django.contrib.auth.models import User
from rest_framework import serializers

from AutoAPI.serializers.BaseSerializer import BaseSerializer
from AutoAPI.models import CaseAPIResponse
from AutoAPI.serializers.AutoTestCaseAPISerializer import AutoTestCaseAPINestSerializer


# 用例响应反序列化
class CaseAPIResponseSerializer(serializers.ModelSerializer, BaseSerializer):
    class Meta:
        model = CaseAPIResponse
        fields = "__all__"


# 用例响应序列化
class CaseAPIResponseOutSerializer(serializers.ModelSerializer, BaseSerializer):
    case = AutoTestCaseAPINestSerializer()

    class Meta:
        model = CaseAPIResponse
        fields = "__all__"


# 用例响应嵌套序列化
class CaseAPIResponseNestSerializer(serializers.ModelSerializer, BaseSerializer):
    case = serializers.CharField(source='case.name')

    class Meta:
        model = CaseAPIResponse
        fields = "__all__"
