from django.contrib.auth.models import User
from rest_framework import serializers

from AutoAPI.serializers.BaseSerializer import BaseSerializer
from AutoAPI.models import Environment
from AutoAPI.serializers.ProjectSerializer import ProjectNestSerializer


# 环境管理反序列化
class EnvironmentSerializer(serializers.ModelSerializer, BaseSerializer):
    class Meta:
        model = Environment
        fields = "__all__"


# 环境管理序列化
class EnvironmentOutSerializer(serializers.ModelSerializer, BaseSerializer):
    project = ProjectNestSerializer()
    user = serializers.CharField(source='user.username')

    class Meta:
        model = Environment
        fields = "__all__"


# 环境管理嵌套序列化
class EnvironmentNestSerializer(serializers.ModelSerializer, BaseSerializer):
    project = serializers.CharField(source='project.title')
    user = serializers.CharField(source='user.username')

    class Meta:
        model = Environment
        fields = "__all__"
