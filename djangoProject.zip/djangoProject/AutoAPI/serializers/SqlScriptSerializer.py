from django.contrib.auth.models import User
from rest_framework import serializers

from AutoAPI.serializers.BaseSerializer import BaseSerializer
from AutoAPI.models import SqlScript
from AutoAPI.serializers.DataBaseConnectSerializer import DataBaseConnectNestSerializer


# sql脚本反序列化
class SqlScriptSerializer(serializers.ModelSerializer, BaseSerializer):
    class Meta:
        model = SqlScript
        fields = "__all__"


# sql脚本序列化
class SqlScriptOutSerializer(serializers.ModelSerializer, BaseSerializer):
    data_base = DataBaseConnectNestSerializer()
    user = serializers.CharField(source='user.username')

    class Meta:
        model = SqlScript
        fields = "__all__"


# sql脚本嵌套序列化
class SqlScriptNestSerializer(serializers.ModelSerializer, BaseSerializer):
    data_base = serializers.CharField(source='data_base.title')
    user = serializers.CharField(source='user.username')

    class Meta:
        model = SqlScript
        fields = "__all__"
