from django.contrib.auth.models import User
from rest_framework import serializers

from AutoAPI.serializers.BaseSerializer import BaseSerializer
from AutoAPI.models import AutoTestCaseGroup
from AutoAPI.serializers.ProjectSerializer import ProjectNestSerializer


# 用例分组反序列化
class AutoTestCaseGroupSerializer(serializers.ModelSerializer, BaseSerializer):
    class Meta:
        model = AutoTestCaseGroup
        fields = "__all__"


# 用例分组序列化
class AutoTestCaseGroupOutSerializer(serializers.ModelSerializer, BaseSerializer):
    project = ProjectNestSerializer()
    user = serializers.CharField(source='user.username')

    class Meta:
        model = AutoTestCaseGroup
        fields = "__all__"


# 用例分组嵌套序列化
class AutoTestCaseGroupNestSerializer(serializers.ModelSerializer, BaseSerializer):
    project = serializers.CharField(source='project.title')
    user = serializers.CharField(source='user.username')

    class Meta:
        model = AutoTestCaseGroup
        fields = "__all__"
