from django.contrib.auth.models import User
from rest_framework import serializers

from AutoAPI.serializers.BaseSerializer import BaseSerializer
from AutoAPI.models import APIRequestHistory
from AutoAPI.serializers.APIDetailSerializer import APIDetailNestSerializer


# 接口请求历史反序列化
class APIRequestHistorySerializer(serializers.ModelSerializer, BaseSerializer):
    class Meta:
        model = APIRequestHistory
        fields = "__all__"


# 接口请求历史序列化
class APIRequestHistoryOutSerializer(serializers.ModelSerializer, BaseSerializer):
    api = APIDetailNestSerializer()

    class Meta:
        model = APIRequestHistory
        fields = "__all__"


# 接口请求历史嵌套序列化
class APIRequestHistoryNestSerializer(serializers.ModelSerializer, BaseSerializer):
    api = serializers.CharField(source='api.name')

    class Meta:
        model = APIRequestHistory
        fields = "__all__"
