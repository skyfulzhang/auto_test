from django.contrib.auth.models import User
from rest_framework import serializers

from AutoAPI.serializers.BaseSerializer import BaseSerializer
from AutoAPI.models import GlobalVariable
from AutoAPI.serializers.ProjectSerializer import ProjectNestSerializer


# 全局变量反序列化
class GlobalVariableSerializer(serializers.ModelSerializer, BaseSerializer):
    class Meta:
        model = GlobalVariable
        fields = "__all__"


# 全局变量序列化
class GlobalVariableOutSerializer(serializers.ModelSerializer, BaseSerializer):
    project = ProjectNestSerializer()
    user = serializers.CharField(source='user.username')

    class Meta:
        model = GlobalVariable
        fields = "__all__"


# 全局变量嵌套序列化
class GlobalVariableNestSerializer(serializers.ModelSerializer, BaseSerializer):
    project = serializers.CharField(source='project.title')
    user = serializers.CharField(source='user.username')

    class Meta:
        model = GlobalVariable
        fields = "__all__"
