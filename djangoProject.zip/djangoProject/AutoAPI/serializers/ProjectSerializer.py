from django.contrib.auth.models import User
from rest_framework import serializers

from AutoAPI.serializers.BaseSerializer import BaseSerializer
from AutoAPI.models import Project
from AutoAPI.serializers.UserSerializer import UserSerializer


# 项目信息反序列化
class ProjectSerializer(serializers.ModelSerializer, BaseSerializer):
    class Meta:
        model = Project
        fields = "__all__"


# 项目信息序列化
class ProjectOutSerializer(serializers.ModelSerializer, BaseSerializer):
    project_type_choices = (("WEB", "web"), ("APP", "app"), ("MINI", "mini"))
    project_type = serializers.ChoiceField(choices=project_type_choices, source="get_project_type_display")
    user = UserSerializer()

    class Meta:
        model = Project
        fields = "__all__"


# 项目信息嵌套序列化
class ProjectNestSerializer(serializers.ModelSerializer, BaseSerializer):
    project_type_choices = (("WEB", "web"), ("APP", "app"), ("MINI", "mini"))
    project_type = serializers.ChoiceField(choices=project_type_choices, source="get_project_type_display")
    user = serializers.CharField(source='user.username')

    class Meta:
        model = Project
        fields = "__all__"
