from django.contrib.auth.models import User
from rest_framework import serializers

from AutoAPI.serializers.BaseSerializer import BaseSerializer
from AutoAPI.models import APIGroup
from AutoAPI.serializers.APIModuleSerializer import APIModuleSerializer


# 接口分组反序列化
class APIGroupSerializer(serializers.ModelSerializer, BaseSerializer):
    class Meta:
        model = APIGroup
        fields = "__all__"


# 接口分组序列化
class APIGroupOutSerializer(serializers.ModelSerializer, BaseSerializer):
    module = APIModuleSerializer()
    user = serializers.CharField(source='user.username')

    class Meta:
        model = APIGroup
        fields = "__all__"


# 接口分组嵌套序列化
class APIGroupNestSerializer(serializers.ModelSerializer, BaseSerializer):
    module = serializers.CharField(source='module.title')
    user = serializers.CharField(source='user.username')

    class Meta:
        model = APIGroup
        fields = "__all__"
