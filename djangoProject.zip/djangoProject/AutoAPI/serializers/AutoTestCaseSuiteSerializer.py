from django.contrib.auth.models import User
from rest_framework import serializers

from AutoAPI.serializers.BaseSerializer import BaseSerializer
from AutoAPI.models import AutoTestCaseSuite
from AutoAPI.serializers.AutoTestCaseGroupSerializer import AutoTestCaseGroupNestSerializer


# 用例分组反序列化
class AutoTestCaseSuiteSerializer(serializers.ModelSerializer, BaseSerializer):
    class Meta:
        model = AutoTestCaseSuite
        fields = "__all__"


# 用例分组序列化
class AutoTestCaseSuiteOutSerializer(serializers.ModelSerializer, BaseSerializer):
    group = AutoTestCaseGroupNestSerializer()
    user = serializers.CharField(source='user.username')

    class Meta:
        model = AutoTestCaseSuite
        fields = "__all__"


# 用例分组嵌套序列化
class AutoTestCaseSuiteNestSerializer(serializers.ModelSerializer, BaseSerializer):
    group = serializers.CharField(source='group.title')
    user = serializers.CharField(source='user.username')

    class Meta:
        model = AutoTestCaseSuite
        fields = "__all__"
