from django.contrib.auth.models import User
from rest_framework import serializers

from AutoAPI.serializers.BaseSerializer import BaseSerializer
from AutoAPI.models import AutoCaseTask
from AutoAPI.serializers.EnvironmentSerializer import EnvironmentNestSerializer
from AutoAPI.serializers.AutoTestCaseSuiteSerializer import AutoTestCaseSuiteNestSerializer


# 定时任务反序列化
class AutoCaseTaskSerializer(serializers.ModelSerializer, BaseSerializer):
    class Meta:
        model = AutoCaseTask
        fields = "__all__"


# 定时任务序列化
class AutoCaseTaskOutSerializer(serializers.ModelSerializer, BaseSerializer):
    environment = EnvironmentNestSerializer()
    suite = AutoTestCaseSuiteNestSerializer()
    user = serializers.CharField(source='user.username')

    class Meta:
        model = AutoCaseTask
        fields = "__all__"


# 定时任务嵌套序列化
class AutoCaseTaskNestSerializer(serializers.ModelSerializer, BaseSerializer):
    environment = serializers.CharField(source='environment.title')
    suite = serializers.CharField(source='suite.title')
    user = serializers.CharField(source='user.username')

    class Meta:
        model = AutoCaseTask
        fields = "__all__"
