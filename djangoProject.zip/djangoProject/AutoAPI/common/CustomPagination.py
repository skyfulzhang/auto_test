from rest_framework.pagination import PageNumberPagination, CursorPagination


# 根据页码进行分页
class CustomPagination(PageNumberPagination):
    page_size = 10
    page_size_query_description = "每页返回的数据条数"
    page_size_query_param = 'size'
    page_query_param = "page"
    page_query_description = "分页后的页码字段"
    max_page_size = 100


# 加密游标分页，性能最好
class CursorPagination(CursorPagination):
    # URL传入的游标参数
    cursor_query_param = 'cursor'
    # 默认每页显示的数据条数
    page_size = 10
    # URL传入的每页显示条数的参数
    page_size_query_param = 'size'
    # 每页显示数据最大条数
    max_page_size = 100
    # 根据ID从大到小排列
    ordering = "id"
