import logging
from rest_framework.views import exception_handler
from rest_framework.response import Response

logger = logging.getLogger("django")


def custom_exception_handler(exc, context):
    logger.error('[异常信息]: %s' % str({"view": context.get("view"), "exception": exc}))
    # 先调用REST framework默认的异常处理方法获得标准错误响应对象
    response = exception_handler(exc, context)
    # 在此处补充自定义的异常处理
    if response is None:
        response = Response({"detail": "服务器异常"}, status=500)
    return response
