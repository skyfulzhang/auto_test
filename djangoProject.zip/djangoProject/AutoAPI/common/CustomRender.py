from rest_framework.renderers import JSONRenderer


class BaseResponse(object):

    def __init__(self):
        self.code = None
        self.message = None
        self.data = None

    @property
    def dict(self):
        res = {
            "code": self.code,
            "message": self.message,
            "data": self.data,
        }
        return res


# 自定义渲染器
class CustomJSONRenderer(JSONRenderer):
    def render(self, data, accepted_media_type=None, renderer_context=None):
        response = renderer_context.get("response", None)
        body_data = BaseResponse()
        if response:
            body_data.code = response.status_code
            if response.status_code >= 400:
                body_data.message = data.get("detail", None)
            else:
                body_data.data = data
            return super().render(body_data.dict, accepted_media_type, renderer_context)
        else:
            return super().render(data, accepted_media_type, renderer_context)
