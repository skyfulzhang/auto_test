from django.contrib.auth.models import User
from django.db import models
from django.contrib.auth.models import AbstractUser

"""

project ---> module --->group--->api

Project:项目信息表，包含项目的基本信息
ProjectMember：项目成员表，用于权限管理

GlobalHost：全局变量，归属于项目，一个项目可以有多个host环境

ApiModule：接口模块，每个模块里面有多个分组
ApiGroup：接口分组，每个组里面有多个接口
ApiInfo：接口的基本信息，包含name,url,method等信息

ApiRequestParameter:请求参数分为args,form-data,json,直接分3种去存

    注意：key-value的形式种，value有3种数据类型，string,int,bool，前端去处理

group --->suite --->case

AutoCaseGroup:用例分组，每个分组下面有多个用例
AutoCaseSuite:用例集，每个用例集下面有多个用例
AutoCaseAPi:测试用例，可以直接和ApiInfo关联，包含结果提取，结果校验
    结果校验的值可以有：不校验，jsonpath提取，正则表达式，DeepDiff,完全校验，数据库校验

AutoTestResult：单次测试结果，保存接口的全部信息，关联AutoCaseAPi
AutoCaseResult：用例执行结果，保存接口的全部信息，关联AutoCaseSuite
AutoTestTaskJob:定时任务，执行方式用时间间隔

DataBaseClient:数据库连接,包括开发环境，测试环境，线上环境等
SqlScript:数据库脚本，sql语句，关联DataBaseClient
GlobalVariable:全局变量，用于存储公共的变量，比如token，参数提取
    可以将extract的数据存入全局变量
    全局变量使用${vars}的方式使用，使用from string import Template的方式转换


"""


# Create your models here.

class UserProfile(AbstractUser):
    nick_name = models.CharField(max_length=64, verbose_name='昵称', default='')
    birthday = models.DateField(null=True, blank=True, verbose_name='生日')
    gender = models.CharField(max_length=16, choices=(('male', '男'), ('female', '女')), default='male',
                              verbose_name='性别')
    position = models.CharField(max_length=64, default='', verbose_name='职位')
    mobile = models.CharField(max_length=11, null=True, blank=True, verbose_name='手机号')

    def __str__(self):
        return self.username

    class Meta:
        verbose_name = '用户信息'
        verbose_name_plural = verbose_name


class Project(models.Model):
    id = models.AutoField(primary_key=True, null=False)
    project_type_choices = (("WEB", "web"), ("APP", "app"), ("MINI", "mini"))
    title = models.CharField(max_length=64, null=False, blank=False, verbose_name='项目名称')
    desc = models.TextField(blank=True, null=True, verbose_name='描述')
    project_type = models.CharField(max_length=64, choices=project_type_choices, verbose_name='类型')
    user = models.ForeignKey(UserProfile, on_delete=models.CASCADE, verbose_name='创建人')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    update_time = models.DateTimeField(auto_now=True, verbose_name='修改时间')

    def __str__(self):
        return self.title

    class Meta:
        db_table = 'project'
        ordering = ["-create_time"]
        verbose_name = '项目信息'
        verbose_name_plural = verbose_name


# class ProjectMember(models.Model):
#     """
#     项目成员
#     """
#     id = models.AutoField(primary_key=True, null=False)
#     member_type = (('Manager', 1), ('Developer', 2), ('Tester', 3), ('Guest', 4))
#     name = models.CharField(max_length=32, null=False, blank=False, verbose_name='成员姓名')
#     member_type = models.CharField(max_length=32, choices=member_type, verbose_name='成员角色', )
#     project = models.ForeignKey(Project, related_name='member_project', on_delete=models.CASCADE, verbose_name='所属项目')
#     user = models.ForeignKey(UserProfile, related_name='member_user', on_delete=models.CASCADE, verbose_name='用户')
#     create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
#     update_time = models.DateTimeField(auto_now=True, verbose_name='修改时间')
#
#     def __str__(self):
#         return self.name
#
#     class Meta:
#         db_table = 'project_member'
#         ordering = ["-create_time"]
#         verbose_name = '项目成员'
#         verbose_name_plural = verbose_name


class Environment(models.Model):
    """
    host环境域名,包含host,port
    """
    id = models.AutoField(primary_key=True, null=False)
    title = models.CharField(max_length=64, null=False, blank=False, verbose_name='名称')
    address = models.CharField(max_length=64, null=False, blank=False, verbose_name='Host地址')
    security_key = models.TextField(blank=True, null=True, verbose_name='密钥配置')
    is_active = models.BooleanField(default=True, verbose_name='激活状态')
    project = models.ForeignKey(Project, on_delete=models.CASCADE, verbose_name='项目')
    user = models.ForeignKey(UserProfile, on_delete=models.CASCADE, verbose_name='创建人')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    update_time = models.DateTimeField(auto_now=True, verbose_name='修改时间')

    def __str__(self):
        return self.title

    class Meta:
        db_table = 'environment'
        ordering = ["-create_time"]
        verbose_name = '环境管理'
        verbose_name_plural = verbose_name


class APIModule(models.Model):
    """
    接口模块
    """
    id = models.AutoField(primary_key=True, null=False)
    title = models.CharField(max_length=64, null=False, blank=False, verbose_name='模块名称')
    project = models.ForeignKey(Project, on_delete=models.CASCADE, verbose_name='项目')
    user = models.ForeignKey(UserProfile, on_delete=models.CASCADE, verbose_name='创建人')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    update_time = models.DateTimeField(auto_now=True, verbose_name='修改时间')

    def __str__(self):
        return self.title

    class Meta:
        db_table = 'api_module'
        ordering = ["-create_time"]
        verbose_name = '接口模块'
        verbose_name_plural = verbose_name


class APIGroup(models.Model):
    """
    接口分组
    """
    id = models.AutoField(primary_key=True, null=False)
    title = models.CharField(max_length=64, null=False, blank=False, verbose_name='分组名称')
    module = models.ForeignKey(APIModule, on_delete=models.CASCADE, verbose_name='模块')
    user = models.ForeignKey(UserProfile, on_delete=models.CASCADE, verbose_name='创建人')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    update_time = models.DateTimeField(auto_now=True, verbose_name='修改时间')

    def __str__(self):
        return self.title

    class Meta:
        db_table = 'api_group'
        ordering = ["-create_time"]
        verbose_name = '接口分组'
        verbose_name_plural = verbose_name


class APIDetail(models.Model):
    """
    接口信息
    """
    method_type_choices = (("GET", "GET"), ("POST", "POST"), ("PUT", "PUT"), ("DELETE", "DELETE"))
    parameter_type_choices = (("PARAMS", "params"), ("FORM-DATA", "form-data"), ("JSON", "json"), ("FILE", "file"))
    id = models.AutoField(primary_key=True, null=False)
    name = models.CharField(max_length=64, null=False, blank=False, verbose_name='接口名称')
    url_path = models.CharField(max_length=64, null=False, blank=False, verbose_name='接口地址')
    method_type = models.CharField(max_length=64, choices=method_type_choices, verbose_name='请求方式')
    headers = models.TextField(blank=True, null=True, verbose_name='请求头信息')
    parameter_type = models.CharField(max_length=64, choices=parameter_type_choices, verbose_name='参数格式')
    param_data = models.TextField(blank=True, null=True, verbose_name='请求参数数据')
    is_active = models.BooleanField(default=True, verbose_name='激活状态')
    is_mock = models.BooleanField(default=False, verbose_name="mock状态")
    mock_data = models.TextField(blank=True, null=True, verbose_name='mock内容')
    environment = models.ForeignKey(Environment, on_delete=models.CASCADE, related_name='api_environment',
                                    verbose_name='环境')
    group = models.ForeignKey(APIGroup, on_delete=models.CASCADE, related_name='api_group', verbose_name='分组')
    user = models.ForeignKey(UserProfile, on_delete=models.CASCADE, verbose_name='创建人')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    update_time = models.DateTimeField(auto_now=True, verbose_name='修改时间')

    def __str__(self):
        return self.name

    class Meta:
        db_table = 'api_detail'
        ordering = ["-create_time"]
        verbose_name = '接口信息'
        verbose_name_plural = verbose_name


class APIRequestHistory(models.Model):
    """
    接口请求历史
    """
    id = models.AutoField(primary_key=True, null=False)
    url = models.CharField(max_length=64, null=False, blank=False, verbose_name='url地址')
    method = models.CharField(max_length=64, null=False, blank=False, verbose_name='请求方式')
    api = models.ForeignKey(APIDetail, on_delete=models.CASCADE, related_name='history_api', verbose_name='接口信息')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    update_time = models.DateTimeField(auto_now=True, verbose_name='修改时间')

    def __unicode__(self):
        return self.api.name

    class Meta:
        db_table = 'api_history'
        ordering = ["-create_time"]
        verbose_name = '接口请求历史'
        verbose_name_plural = '接口请求历史'


class AutoTestCaseGroup(models.Model):
    """
    测试用例分组
    """
    id = models.AutoField(primary_key=True, null=False)
    title = models.CharField(max_length=64, null=False, blank=False, verbose_name="用例分组名称")
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='case_project', verbose_name="项目名称", )
    user = models.ForeignKey(UserProfile, on_delete=models.CASCADE, verbose_name='创建人')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    update_time = models.DateTimeField(auto_now=True, verbose_name='修改时间')

    def __str__(self):
        return self.title

    class Meta:
        db_table = 'case_group'
        ordering = ["-create_time"]
        verbose_name = '测试用例分组'
        verbose_name_plural = verbose_name


class AutoTestCaseSuite(models.Model):
    """
    测试用例集
    """
    id = models.AutoField(primary_key=True, null=False)
    title = models.CharField(max_length=64, null=False, blank=False, verbose_name="用例集名称")
    group = models.ForeignKey(AutoTestCaseGroup, on_delete=models.CASCADE, related_name='case_group',
                              verbose_name="测试分组", )
    user = models.ForeignKey(UserProfile, on_delete=models.CASCADE, verbose_name='创建人')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    update_time = models.DateTimeField(auto_now=True, verbose_name='修改时间')

    def __str__(self):
        return self.title

    class Meta:
        db_table = 'case_suite'
        ordering = ["-create_time"]
        verbose_name = '测试用例集'
        verbose_name_plural = verbose_name


class AutoTestCaseAPI(models.Model):
    """
    接口测试用例
    """
    # 断言类型
    assert_type_choices = (
        ("GREATER-THAN", "greater_than"), ("LESS-THAN", "less_than"), ("EQUAL", "equal"), ("NOT-EQUAL", "not_equal"),
        ("CONTAIN", "contain"), ("NOT-CONTAIN", "not_contain"), ("IS-NULL", "is_null"), ("NOT-NULL", "not_null"))
    # 校验类型
    check_type_choices = (
        ("NO-CHECK", "no_check"), ("KEY_WORDs", "key_words"), ("COMPILE-CHECK", "complete_check"),)
    id = models.AutoField(primary_key=True, null=False)
    name = models.CharField(max_length=64, null=False, blank=False, verbose_name="测试用例名称")
    # 参数提取包含名称、描述、变量名称、表达式、缺省值等信息，表达式为jsonpath表达式，提取失败时的缺省值为空
    extract = models.TextField(blank=True, null=True, verbose_name='参数提取')
    # 校验方式分为不校验，关键字校验和完全校验
    check_type = models.CharField(max_length=64, choices=check_type_choices, default='no_check', verbose_name='校验类型')
    # 断言方式包含全等，大于，小于，等于，不等，包含，为空等情况
    assert_type = models.CharField(max_length=64, choices=assert_type_choices, default='equal', verbose_name='断言方式')
    # 期望结果直接是json格式的数据，以key-value的形式循环断言判断
    expect = models.TextField(blank=True, null=True, verbose_name='期望结果')
    is_run = models.BooleanField(default=False, verbose_name='是否运行')
    message = models.TextField(blank=True, null=True, verbose_name='异常信息')
    api = models.ForeignKey(APIDetail, on_delete=models.CASCADE, related_name='case_api', verbose_name="所属接口", )
    environment = models.ForeignKey(Environment, on_delete=models.CASCADE, related_name='case_environment',
                                    verbose_name='环境')
    suite = models.ForeignKey(AutoTestCaseSuite, on_delete=models.CASCADE, related_name='case_suite',
                              verbose_name="用例集", )
    user = models.ForeignKey(UserProfile, on_delete=models.CASCADE, verbose_name='创建人')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    update_time = models.DateTimeField(auto_now=True, verbose_name='修改时间')

    def __str__(self):
        return self.name

    class Meta:
        db_table = 'case_api'
        ordering = ["-create_time"]
        verbose_name = '测试用例'
        verbose_name_plural = verbose_name


class CaseAPIResponse(models.Model):
    """
    用例接口响应
    """
    id = models.AutoField(primary_key=True, null=False)
    url = models.CharField(max_length=64, null=False, blank=False, verbose_name='url地址')
    method = models.CharField(max_length=64, null=False, blank=False, verbose_name='请求方式')
    headers = models.TextField(blank=True, null=True, verbose_name='请求头信息')
    parameter = models.TextField(blank=True, null=True, verbose_name='请求参数数据')
    expect = models.TextField(blank=True, null=True, verbose_name='期望结果')
    assert_type = models.CharField(max_length=64, verbose_name='断言方式')
    status_code = models.IntegerField(null=False, blank=False, verbose_name="响应状态码")
    response_headers = models.TextField(blank=True, null=True, verbose_name='响应头')
    response_body = models.TextField(blank=True, null=True, verbose_name='响应内容')
    process_time = models.DecimalField(max_digits=10, decimal_places=8, verbose_name='响应时间')
    test_result = models.BooleanField(verbose_name='测试结果')
    case = models.ForeignKey(AutoTestCaseAPI, on_delete=models.CASCADE, related_name='case_response',
                             verbose_name="用例响应", )
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    update_time = models.DateTimeField(auto_now=True, verbose_name='修改时间')

    def __str__(self):
        return self.case.name

    class Meta:
        db_table = 'case_response'
        ordering = ["-create_time"]
        verbose_name = '用例响应'
        verbose_name_plural = verbose_name


# class AutoTestResult(models.Model):
#     """
#     单次运行测试结果
#     """
#     id = models.AutoField(primary_key=True, null=False)
#     process_time = models.DecimalField(max_digits=10, decimal_places=8, verbose_name='响应时间')
#     result = models.BooleanField(verbose_name='测试结果')
#     case = models.ForeignKey(AutoCaseApi, on_delete=models.CASCADE, related_name='result_case', verbose_name="接口信息", )
#     response = models.ForeignKey(ApiResponse, on_delete=models.CASCADE, related_name='result_response',
#                                  verbose_name="接口结果", )
#     create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
#     update_time = models.DateTimeField(auto_now=True, verbose_name='修改时间')
#
#     def __str__(self):
#         return self.case.name
#
#     class Meta:
#         db_table = 'test_result'
#         ordering = ["-create_time"]
#         verbose_name = '测试结果'
#         verbose_name_plural = verbose_name


class DataBaseConnect(models.Model):
    """
    数据库信息
    """
    id = models.AutoField(primary_key=True, null=False)
    title = models.CharField(max_length=64, null=False, blank=False, verbose_name="数据库名称")
    address = models.CharField(max_length=64, null=False, blank=False, verbose_name="连接地址")
    username = models.CharField(max_length=64, null=False, blank=False, verbose_name="用户名")
    password = models.CharField(max_length=64, null=False, blank=False, verbose_name="密码")
    data_base = models.CharField(max_length=64, null=False, blank=False, verbose_name="数据库名称")
    charset = models.CharField(max_length=64, default="utf8", verbose_name="字符集")
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='data_project', verbose_name="项目名称")
    user = models.ForeignKey(UserProfile, on_delete=models.CASCADE, verbose_name='创建人')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    update_time = models.DateTimeField(auto_now=True, verbose_name='修改时间')

    def __str__(self):
        return self.title

    class Meta:
        db_table = 'database'
        ordering = ["-create_time"]
        verbose_name = '数据库信息'
        verbose_name_plural = verbose_name


class SqlScript(models.Model):
    """
    数据库脚本
    """
    id = models.AutoField(primary_key=True, null=False)
    title = models.CharField(max_length=64, null=False, blank=False, verbose_name="脚本名称")
    script = models.TextField(null=False, blank=False, verbose_name="脚本信息")
    result = models.TextField(null=False, blank=False, verbose_name="数据结果")
    data_base = models.ForeignKey(DataBaseConnect, on_delete=models.CASCADE, related_name='sql_script',
                                  verbose_name="数据库")
    user = models.ForeignKey(UserProfile, on_delete=models.CASCADE, verbose_name='创建人')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    update_time = models.DateTimeField(auto_now=True, verbose_name='修改时间')

    def __str__(self):
        return self.title

    class Meta:
        db_table = 'sql_script'
        ordering = ["-create_time"]
        verbose_name = '数据库脚本'
        verbose_name_plural = verbose_name


class GlobalVariable(models.Model):
    """
    全局变量
    """
    id = models.AutoField(primary_key=True, null=False)
    variable = models.TextField(null=False, blank=False, verbose_name="变量数据")
    desc = models.TextField(blank=True, null=True, verbose_name='描述')
    is_active = models.BooleanField(default=True, verbose_name='激活状态')
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='var_project', verbose_name="全局变量", )
    user = models.ForeignKey(UserProfile, on_delete=models.CASCADE, verbose_name='创建人')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    update_time = models.DateTimeField(auto_now=True, verbose_name='修改时间')

    def __str__(self):
        return self.variable

    class Meta:
        db_table = 'variable'
        ordering = ["-create_time"]
        verbose_name = '全局变量'
        verbose_name_plural = verbose_name


class AutoCaseTask(models.Model):
    """
    定时任务
    """
    id = models.AutoField(primary_key=True, null=False)
    title = models.CharField(max_length=64, null=False, blank=False, verbose_name="任务名称")
    cron = models.CharField(max_length=64, blank=True, null=True, verbose_name='表达式')
    is_active = models.BooleanField(default=True, verbose_name='激活状态')
    environment = models.ForeignKey(Environment, on_delete=models.CASCADE, verbose_name="运行环境", )
    suite = models.ForeignKey(AutoTestCaseSuite, on_delete=models.CASCADE, verbose_name="用例集", )
    user = models.ForeignKey(UserProfile, on_delete=models.CASCADE, verbose_name='创建人')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    update_time = models.DateTimeField(auto_now=True, verbose_name='修改时间')

    def __str__(self):
        return self.title

    class Meta:
        db_table = 'case_task'
        ordering = ["-create_time"]
        verbose_name = '定时任务'
        verbose_name_plural = verbose_name
