from rest_framework.viewsets import ModelViewSet

from AutoAPI.models import APIGroup
from AutoAPI.common.CustomPagination import CustomPagination
from AutoAPI.serializers.APIGroupSerializer import APIGroupSerializer, APIGroupOutSerializer


class APIGroupViewSet(ModelViewSet):
    queryset = APIGroup.objects.all().order_by("id")
    pagination_class = CustomPagination

    # 设置动态的Serializer
    def get_serializer_class(self):
        if self.action == "retrieve":
            return APIGroupOutSerializer
        return APIGroupSerializer
