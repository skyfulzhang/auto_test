from rest_framework.viewsets import ModelViewSet

from AutoAPI.models import APIRequestHistory
from AutoAPI.common.CustomPagination import CustomPagination
from AutoAPI.serializers.APIRequestHistorySerializer import APIRequestHistorySerializer, APIRequestHistoryOutSerializer


class APIRequestHistoryViewSet(ModelViewSet):
    queryset = APIRequestHistory.objects.all().order_by("id")
    pagination_class = CustomPagination

    # 设置动态的Serializer
    def get_serializer_class(self):
        if self.action == "retrieve":
            return APIRequestHistoryOutSerializer
        return APIRequestHistorySerializer
