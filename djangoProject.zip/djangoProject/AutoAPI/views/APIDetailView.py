from rest_framework.viewsets import ModelViewSet

from AutoAPI.models import APIDetail
from AutoAPI.common.CustomPagination import CustomPagination
from AutoAPI.serializers.APIDetailSerializer import APIDetailSerializer, APIDetailOutSerializer


class APIDetailViewSet(ModelViewSet):
    queryset = APIDetail.objects.all().order_by("id")
    pagination_class = CustomPagination

    # 设置动态的Serializer
    def get_serializer_class(self):
        if self.action == "retrieve":
            return APIDetailOutSerializer
        return APIDetailSerializer
