from rest_framework.viewsets import ModelViewSet

from AutoAPI.models import Environment
from AutoAPI.common.CustomPagination import CustomPagination
from AutoAPI.serializers.EnvironmentSerializer import EnvironmentSerializer, EnvironmentOutSerializer


class EnvironmentViewSet(ModelViewSet):
    queryset = Environment.objects.all().order_by("id")
    pagination_class = CustomPagination

    # 设置动态的Serializer
    def get_serializer_class(self):
        if self.action == "retrieve":
            return EnvironmentOutSerializer
        return EnvironmentSerializer
