from rest_framework.generics import RetrieveAPIView
from rest_framework.views import APIView
from rest_framework.viewsets import ModelViewSet
from rest_framework.response import Response
from rest_framework.exceptions import APIException

from AutoAPI.models import UserProfile
from AutoAPI.serializers.UserSerializer import UserSerializer


class UserProfileView(APIView):
    def get(self, request, pk=None):
        if pk:
            user_obj = self.get_object(pk)
            serializer_obj = UserSerializer(instance=user_obj)
            return Response({'code': 200, 'msg': "success", 'data': serializer_obj.data})
        else:
            users = UserProfile.objects.all()
            serializer_obj = UserSerializer(instance=users, many=True)
            return Response({'code': 200, 'msg': "success", 'data': serializer_obj.data}, )

    def get_object(self, pk):
        try:
            obj = UserProfile.objects.get(id=pk)
        except Exception:
            raise APIException("参数错误")
        return obj
