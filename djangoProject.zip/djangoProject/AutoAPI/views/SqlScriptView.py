from rest_framework.viewsets import ModelViewSet

from AutoAPI.models import SqlScript
from AutoAPI.common.CustomPagination import CustomPagination
from AutoAPI.serializers.SqlScriptSerializer import SqlScriptSerializer, SqlScriptOutSerializer


class SqlScriptViewSet(ModelViewSet):
    queryset = SqlScript.objects.all().order_by("id")
    pagination_class = CustomPagination

    # 设置动态的Serializer
    def get_serializer_class(self):
        if self.action == "retrieve":
            return SqlScriptOutSerializer
        return SqlScriptSerializer
