from rest_framework.viewsets import ModelViewSet

from AutoAPI.models import APIModule
from AutoAPI.common.CustomPagination import CustomPagination
from AutoAPI.serializers.APIModuleSerializer import APIModuleSerializer, APIModuleOutSerializer


class APIModuleViewSet(ModelViewSet):
    queryset = APIModule.objects.all().order_by("id")
    pagination_class = CustomPagination

    # 设置动态的Serializer
    def get_serializer_class(self):
        if self.action == "retrieve":
            return APIModuleOutSerializer
        return APIModuleSerializer
