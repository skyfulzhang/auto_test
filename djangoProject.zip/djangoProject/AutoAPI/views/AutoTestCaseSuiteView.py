from rest_framework.viewsets import ModelViewSet

from AutoAPI.models import AutoTestCaseSuite
from AutoAPI.common.CustomPagination import CustomPagination
from AutoAPI.serializers.AutoTestCaseSuiteSerializer import AutoTestCaseSuiteSerializer, AutoTestCaseSuiteOutSerializer


class AutoTestCaseSuiteViewSet(ModelViewSet):
    queryset = AutoTestCaseSuite.objects.all().order_by("id")
    pagination_class = CustomPagination

    # 设置动态的Serializer
    def get_serializer_class(self):
        if self.action == "retrieve":
            return AutoTestCaseSuiteOutSerializer
        return AutoTestCaseSuiteSerializer
