from rest_framework.viewsets import ModelViewSet

from AutoAPI.models import AutoTestCaseAPI
from AutoAPI.common.CustomPagination import CustomPagination
from AutoAPI.serializers.AutoTestCaseAPISerializer import AutoTestCaseAPISerializer, AutoTestCaseAPIOutSerializer


class AutoTestCaseAPIViewSet(ModelViewSet):
    queryset = AutoTestCaseAPI.objects.all().order_by("id")
    pagination_class = CustomPagination

    # 设置动态的Serializer
    def get_serializer_class(self):
        if self.action == "retrieve":
            return AutoTestCaseAPIOutSerializer
        return AutoTestCaseAPISerializer
