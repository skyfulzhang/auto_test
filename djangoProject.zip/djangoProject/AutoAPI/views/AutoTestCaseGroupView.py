from rest_framework.viewsets import ModelViewSet

from AutoAPI.models import AutoTestCaseGroup
from AutoAPI.common.CustomPagination import CustomPagination
from AutoAPI.serializers.AutoTestCaseGroupSerializer import AutoTestCaseGroupSerializer, AutoTestCaseGroupOutSerializer


class AutoTestCaseGroupViewSet(ModelViewSet):
    queryset = AutoTestCaseGroup.objects.all().order_by("id")
    pagination_class = CustomPagination

    # 设置动态的Serializer
    def get_serializer_class(self):
        if self.action == "retrieve":
            return AutoTestCaseGroupOutSerializer
        return AutoTestCaseGroupSerializer
