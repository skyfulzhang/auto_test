from django.contrib import admin


# Register your models here.
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ["id", "username", "email", "is_superuser", "date_joined", ]
    list_filter = ["username", "email", "is_superuser", ]
    search_fields = ['username', "email", ]
    # ordering设置默认排序字段，负号表示降序排序
    ordering = ('-date_joined',)
    # list_editable 设置默认可编辑字段
    list_editable = ['is_superuser']
    # 详细时间分层筛选
    date_hierarchy = "date_joined"


class ProjectAdmin(admin.ModelAdmin):
    list_display = ["id", "title", "desc", "project_type", "create_time", ]
    list_filter = ["title", "project_type", ]
    search_fields = ['title', "desc", ]
    # ordering设置默认排序字段，负号表示降序排序
    ordering = ('-create_time',)
    # list_editable 设置默认可编辑字段
    list_editable = ['project_type']
    # fk_fields 设置显示外键字段
    fk_fields = ('user_username',)
    # 详细时间分层筛选
    date_hierarchy = "create_time"


class EnvironmentAdmin(admin.ModelAdmin):
    list_display = ["id", "title", "address", "security_key", "is_active", "create_time"]
    list_filter = ["title", "address", "is_active"]
    search_fields = ['title', "address", ]
    # ordering设置默认排序字段，负号表示降序排序
    ordering = ('-create_time',)
    # list_editable 设置默认可编辑字段
    list_editable = ['is_active']
    # fk_fields 设置显示外键字段
    fk_fields = ('project_title',)
    # 详细时间分层筛选
    date_hierarchy = "create_time"


class APIModuleAdmin(admin.ModelAdmin):
    list_display = ["id", "title", "project", "create_time"]
    list_filter = ["title", ]
    search_fields = ['title', ]
    # ordering设置默认排序字段，负号表示降序排序
    ordering = ('-create_time',)
    # fk_fields 设置显示外键字段
    fk_fields = ('project_title',)
    # 详细时间分层筛选
    date_hierarchy = "create_time"


class APIGroupAdmin(admin.ModelAdmin):
    list_display = ["id", "title", "module", "create_time"]
    list_filter = ["title", ]
    search_fields = ['title', ]
    # ordering设置默认排序字段，负号表示降序排序
    ordering = ('-create_time',)
    # fk_fields 设置显示外键字段
    fk_fields = ('project_title',)
    # 详细时间分层筛选
    date_hierarchy = "create_time"


class APIDetailAdmin(admin.ModelAdmin):
    list_display = ["id", "name", "url_path", "method_type", "is_active", "is_mock", "create_time"]
    list_filter = ["name", "url_path", "method_type"]
    search_fields = ['name', "url_path", ]
    # ordering设置默认排序字段，负号表示降序排序
    ordering = ('-create_time',)
    # list_editable 设置默认可编辑字段
    list_editable = ['is_active', 'is_mock']
    # fk_fields 设置显示外键字段
    fk_fields = ('group_title',)
    # 详细时间分层筛选
    date_hierarchy = "create_time"


class APIRequestHistoryAdmin(admin.ModelAdmin):
    list_display = ["id", "url", "method", "create_time"]
    list_filter = ["url", "method"]
    search_fields = ["url", "method"]
    # ordering设置默认排序字段，负号表示降序排序
    ordering = ('-create_time',)
    # fk_fields 设置显示外键字段
    fk_fields = ('API_name',)
    # 详细时间分层筛选
    date_hierarchy = "create_time"


class AutoTestCaseGroupAdmin(admin.ModelAdmin):
    list_display = ["id", "title", "project", "create_time"]
    list_filter = ["title", ]
    search_fields = ["title", ]
    # ordering设置默认排序字段，负号表示降序排序
    ordering = ('-create_time',)
    # fk_fields 设置显示外键字段
    fk_fields = ('project_title',)
    # 详细时间分层筛选
    date_hierarchy = "create_time"


class AutoTestCaseSuiteAdmin(admin.ModelAdmin):
    list_display = ["id", "title", "group", "create_time"]
    list_filter = ["title", ]
    search_fields = ["title", ]
    # ordering设置默认排序字段，负号表示降序排序
    ordering = ('-create_time',)
    # fk_fields 设置显示外键字段
    fk_fields = ('group_title',)
    # 详细时间分层筛选
    date_hierarchy = "create_time"


class AutoTestCaseAPIAdmin(admin.ModelAdmin):
    list_display = ["id", "name", "extract", "check_type", "assert_type", "expect", "is_run", "create_time"]
    list_filter = ["name", "check_type", "assert_type"]
    search_fields = ["name", "check_type", "assert_type"]
    # ordering设置默认排序字段，负号表示降序排序
    ordering = ('-create_time',)
    # list_editable 设置默认可编辑字段
    list_editable = ['is_run']
    # fk_fields 设置显示外键字段
    fk_fields = ('API_name', 'environment_title', 'suite_title')
    # 详细时间分层筛选
    date_hierarchy = "create_time"


class CaseAPIResponseAdmin(admin.ModelAdmin):
    list_display = ["id", "url", "method", "expect", "response_body", "process_time", "test_result",
                    "create_time"]
    list_filter = ["url", "method", "response_body"]
    search_fields = ["url", "method", "response_body"]
    # ordering设置默认排序字段，负号表示降序排序
    ordering = ('-create_time',)
    # list_editable 设置默认可编辑字段
    list_editable = ['test_result']
    # fk_fields 设置显示外键字段
    fk_fields = ('case_API_name',)
    # 详细时间分层筛选
    date_hierarchy = "create_time"


class DataBaseConnectAdmin(admin.ModelAdmin):
    list_display = ["id", "title", "address", "username", "password", "data_base", "create_time"]
    list_filter = ["title", "address", "username", "password"]
    search_fields = ["title", "address", "username", "password"]
    # ordering设置默认排序字段，负号表示降序排序
    ordering = ('-create_time',)
    # fk_fields 设置显示外键字段
    fk_fields = ('project_title',)
    # 详细时间分层筛选
    date_hierarchy = "create_time"


class SqlScriptAdmin(admin.ModelAdmin):
    list_display = ["id", "title", "script", "result", "data_base", "create_time"]
    list_filter = ["title", "script", ]
    search_fields = ["title", "script", ]
    # ordering设置默认排序字段，负号表示降序排序
    ordering = ('-create_time',)
    # fk_fields 设置显示外键字段
    fk_fields = ('database_name',)
    # 详细时间分层筛选
    date_hierarchy = "create_time"


class AutoCaseTaskAdmin(admin.ModelAdmin):
    list_display = ["id", "title", "cron", "is_active", "environment", "suite", "create_time"]
    list_filter = ["title", "cron", ]
    search_fields = ["title", "cron", ]
    # ordering设置默认排序字段，负号表示降序排序
    ordering = ('-create_time',)
    # fk_fields 设置显示外键字段
    fk_fields = ('suite_title',)
    # 详细时间分层筛选
    date_hierarchy = "create_time"


class GlobalVariableAdmin(admin.ModelAdmin):
    list_display = ["id", "variable", "desc", "is_active", "project", "create_time"]
    list_filter = ["variable", "desc", ]
    search_fields = ["variable", "desc", ]
    # ordering设置默认排序字段，负号表示降序排序
    ordering = ('-create_time',)
    # list_editable 设置默认可编辑字段
    list_editable = ['is_active']
    # fk_fields 设置显示外键字段
    fk_fields = ('project_name',)
    # 详细时间分层筛选
    date_hierarchy = "create_time"


from AutoAPI.models import UserProfile, Project, Environment, APIModule, APIGroup, APIDetail, APIRequestHistory
from AutoAPI.models import AutoTestCaseGroup, AutoTestCaseSuite, AutoTestCaseAPI, CaseAPIResponse
from AutoAPI.models import DataBaseConnect, SqlScript, AutoCaseTask, GlobalVariable

admin.site.register(UserProfile, UserProfileAdmin)
admin.site.register(Project, ProjectAdmin)
admin.site.register(Environment, EnvironmentAdmin)
admin.site.register(APIModule, APIModuleAdmin)
admin.site.register(APIGroup, APIGroupAdmin)
admin.site.register(APIDetail, APIDetailAdmin)
admin.site.register(APIRequestHistory, APIRequestHistoryAdmin)
admin.site.register(AutoTestCaseGroup, AutoTestCaseGroupAdmin)
admin.site.register(AutoTestCaseSuite, AutoTestCaseSuiteAdmin)
admin.site.register(AutoTestCaseAPI, AutoTestCaseAPIAdmin)
admin.site.register(CaseAPIResponse, CaseAPIResponseAdmin)
admin.site.register(DataBaseConnect, DataBaseConnectAdmin)
admin.site.register(SqlScript, SqlScriptAdmin)
admin.site.register(AutoCaseTask, AutoCaseTaskAdmin)
admin.site.register(GlobalVariable, GlobalVariableAdmin)
